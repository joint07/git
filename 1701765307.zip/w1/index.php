<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="case/cases-js/java_query.file.min.js"></script>


        <title>Pixel Pioneers Studio: Criando Mundos, Acendendo Imaginações</title>
        <meta property="og:title" content="Pixel Pioneers Studio: Criando Mundos, Acendendo Imaginações" /> 
        <meta name="keywords" content="blaze, kto, blaze aposta, blaze apostas, kto apostas, brazino777, blaze jogo, brazino, brazino 777" />
        <meta property="og:description" content="Pixel Pioneers Studio: Criando Mundos, Acendendo Imaginações">
        <meta name="description" content="Pixel Pioneers Studio: Criando Mundos, Acendendo Imaginações">
        <link rel="stylesheet" href="case/case-css/boot_strap.css">
        <link rel="stylesheet" href="case/case-css/boot_strap.min.css.map">
        <link rel="stylesheet" href="case/case-css/bottom.css">
        <link rel="stylesheet" href="case/case-css/javacriptquery.fancybox.min.css">
        <link rel="stylesheet" href="case/case-css/icon.css">
        <link rel="stylesheet" href="case/case-css/slick_theme.css">
        <link rel="stylesheet" href="case/case-css/info_slick.css">
        <script src="case/cases-js/jquery.cookie.file.js"></script>
        <script src="case/cases-js/bootstrap.bundle.min.js"></script>
        
        
        <meta property="og:image" content="1710507361.jpg"/>
        <link rel="shortcut icon" href="logotip.svg" type="image/x-icon">
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="case/case-css/media_query.css">
        
        </head>

        <body class="3ifDHCRV_9">
            <style>
            .menu-dropdown .divider,.dropdown-menu .divider{height:1px;margin:5px 0;overflow:hidden;background-color:#eee;border-bottom:1px solid #ffffff;}
.fa-calendar-day:before{content:'783'}
.ul-settings .settings-checkbox .checkbox_span:hover { background-position: -292px -1488px; }
.media-grid a{float:left;padding:4px;margin:0 0 18px 20px;border:1px solid #ddd;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:0 1px 1px rgba(0, 0, 0, 0.075);-moz-box-shadow:0 1px 1px rgba(0, 0, 0, 0.075);box-shadow:0 1px 1px rgba(0, 0, 0, 0.075);}
.inner-box-2 {
    background-color: #fff;
    border: 1px solid #ddd;
    float: left;
    height: 73px;
    margin-left: 0;
    margin-right:0px;
    margin-bottom:13px;
    padding-top: 17px;
    text-align: left;
    width: 308px;
}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background-color: black;
    opacity: .5;
}
.btn.disabled{cursor:default;background-image:none;filter:progid:DXImageTransform.Microsoft.gradient(enabled = false);filter:alpha(opacity=65);-khtml-opacity:0.65;-moz-opacity:0.65;opacity:0.65;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;}
.sg h3 span {
    color: #777777;
    display: block;
    font-size: 17px;
    font-weight: 300;
    letter-spacing: -0.5px;
    padding-top: 4px;
}
.introjs-helperNumberLayer {
  box-sizing: content-box;
  position: absolute;
  visibility: visible;
  top: -16px;
  left: -16px;
  z-index: 9999999999 !important;
  padding: 2px;
  font-family: Arial, verdana, tahoma;
  font-size: 13px;
  font-weight: bold;
  color: white;
  text-align: center;
  text-shadow: 1px 1px 1px rgba(0,0,0,.3);
  background: #ff3019; /* Old browsers */
  background: -webkit-linear-gradient(top, #ff3019 0%, #cf0404 100%); /* Chrome10+,Safari5.1+ */
  background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #ff3019), color-stop(100%, #cf0404)); /* Chrome,Safari4+ */
  background:    -moz-linear-gradient(top, #ff3019 0%, #cf0404 100%); /* FF3.6+ */
  background:     -ms-linear-gradient(top, #ff3019 0%, #cf0404 100%); /* IE10+ */
  background:      -o-linear-gradient(top, #ff3019 0%, #cf0404 100%); /* Opera 11.10+ */
  background:         linear-gradient(to bottom, #ff3019 0%, #cf0404 100%);  /* W3C */
  width: 20px;
  height:20px;
  line-height: 20px;
  border: 3px solid white;
  border-radius: 50%;
  filter: 'progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff3019', endColorstr='#cf0404', GradientType=0)'; /* IE6-9 */
  filter: 'progid:DXImageTransform.Microsoft.Shadow(direction=135, strength=2, color=ff0000)'; /* IE10 text shadows */
  box-shadow: 0 2px 5px rgba(0,0,0,.4);
}
.counhead label{font-size:11px; text-align:left; font-family: ProximaNova-Reg, Arial, Helvetica, sans-serif;}

            </style>

    <script type="text/javascript" src="case/cases-js/date-jquery.js"></script>
               <script>
                $(document).ready(function() {
                    function convertHex(hex,opacity){
                    hex = hex.replace('#','');
                    r = parseInt(hex.substring(0,2), 16);
                    g = parseInt(hex.substring(2,4), 16);
                    b = parseInt(hex.substring(4,6), 16);

                    result = 'rgba('+r+','+g+','+b+','+opacity/100+')';
                    return result;
                    }
                    $('.osmova-main').css('background-color', convertHex('#070739}',60));
                 $('.otziv').css('background-color', convertHex('#070739}',10));
                 $('.destination-back').css('background-color', convertHex('#070739}',30));
                });

</script>
   <script>
        $(window).on('scroll', function () {
            var pixels = 50;
            var top = 1200;
            if ($(window).scrollTop() > pixels) {
            $('.navbar-expand-md').addClass('navbar-reduce');
            $('.navbar-expand-md').removeClass('navbar-trans');
            } else {
            $('.navbar-expand-md').addClass('navbar-trans');
            $('.navbar-expand-md').removeClass('navbar-reduce');
            }
        });
    </script>


    <section class="osnova">
        <div class="osmova-main">
            <header class="main-header">
                <div class="header navbar-expand-md navbar-b navbar-trans flex-row-reverse">
                    <div class="container new-nav">
                        <div class="logo-main">
                        <div>
                            <img src="logotip.svg" alt="logo">
                        </div>
                        <p class="logo-text">
                            Pixel Pioneers Studio
                        </p>
                    </div>
                    <div class="nav">
                        <ul class="navig">
                            <a href="./">Página inicial</a>
                            <button class=" dropdown-toggle" type="button" id="dropdownMenu2" data-bs-toggle="dropdown" aria-expanded="false">
                                Nossos serviços
                            </button>
                            <ul class="dropdown-menu" aria-labelledby="dropdownMenu2">
                                <li><a  href="crafting-visions-into-virtual-realities-at-pixel-pioneers-studio.php"  class="dropdown-item" type="button">Criando visões em realidades virtuais no Pixel Pioneers Studio</a></li>
                                <li><a  href="crafting-visual-masterpieces-in-gaming.php"  class="dropdown-item" type="button">Criando obras-primas visuais em jogos</a></li>
                                <li><a  href="sonic-landscapes-the-art-of-audio-at-pixel-pioneers-studio.php"  class="dropdown-item" type="button">Paisagens Sonoras: A Arte do Áudio no Pixel Pioneers Studio</a></li>
                                <li><a  href="pixel-pioneers-studio-excellence-through-quality-assurance-and-testing.php"  class="dropdown-item" type="button">Pixel Pioneers Studio: excelência através da garantia de qualidade e testes</a></li>
                            </ul>
                            <a href="./#section2">Nossos funcionários</a>
                            <a href="./#section3">Opiniões</a>
                            <a href="contact-page.php">Fale Conosco</a>
                        </ul>
                    </div>
                    </div>

                </div>
            </header>
            <div class="otstypPad container shop-main XH0Z3Utu">
                <div class="shop">
                    <div class="container header-text">
                    <div class="header-text-osnova">Olá, mundo! Estamos muito felizes que você decidiu visitar o nosso site. Prepare-se para explorar a fantástica variedade de ofertas que criamos para melhorar a sua vida. </div>
                     <a href="tel:+553234223334" class="header-text-btn button-7">Obtenha uma consulta</a> 
                </div>
                </div>
            </div>
            <div class="container otstypPad">
                <div class="nagative_margin4">
				<div class="col-lg-4 col-md-6 col-sm-12">
					<div class="single_feature_six">
						<div class="single_feature_six_icon mr-3">
							<i class="block-preim-main-2 bi bi-tablet-fill"></i>
						</div>
						<div class="single_feature_six_content white">
							<h5>Informações sobre o produto</h5>
							<p>Ajudaremos a economizar tempo para os clientes envolvidos no trabalho ou em outras tarefas.</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 col-sm-12">
					<div class="single_feature_six">
						<div class="single_feature_six_icon mr-3">
							<i class="block-preim-main-1 bi bi-bag-check-fill"></i>
						</div>
						<div class="single_feature_six_content white">
							<h5>Programas de fidelidade</h5>
							<p>Os compradores podem comprar de pijama, se quiserem!</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 col-sm-12">
					<div class="single_feature_six">
						<div class="single_feature_six_icon mr-3">
							<i class="block-preim-main-1 bi bi-hand-thumbs-up-fill"></i>
						</div>
						<div class="single_feature_six_content white">
							<h5>Conveniência</h5>
							<p>Temos um programa de fidelidade que recompensa os clientes por suas compras.</p>
						</div>
					</div>
				</div>
			</div>
            </div>
		</div>
    </section>

        

    <div class="main-men flex-column">
         <section id="section1" class="main_area otstypPad">
              <div class="container main flex-row-reverse">
                <div class="main-osnova flex-column">
                    <h2 class="main-title titleSite">Pixel Pioneers Studio: Criando Mundos, Acendendo Imaginações</h2>
                    <div class="main-osnova-new flex-row-reverse">
                        <div class="main-statik">Classificação:  ★ ★ ★ ★ ★ </div>
                        <div class="main-statik"><i class="bi bi-eye-fill"></i> 10282</div>
                    </div>
                    <div class="main-img-osnova 3ifDHCRV">
                        <img class="main-img imgClass" src="1710507361.jpg" alt="Pixel Pioneers Studio: Criando Mundos, Acendendo Imaginações">
                    </div>
                </div>
                <div class="main-text">
                    <p>Bem-vindo ao Pixel Pioneers Studio, onde a criatividade e a tecnologia blaze um caminho no mundo dinâmico do desenvolvimento de jogos para PC. Nosso estúdio é um centro de inovação e imaginação, dedicado a criar experiências de jogo imersivas que cativam, desafiam e divertem. Na Pixel Pioneers, acreditamos em ultrapassar os limites do que é possível, explorando constantemente novas ideias e tecnologias para dar vida às nossas visões.</p>
<p>Nossa equipe é um grupo diversificado de indivíduos talentosos, cada um trazendo suas habilidades e paixões únicas para a mesa. De narrativas atraentes e construção de mundos intrincados a gráficos de ponta e jogabilidade responsiva, cobrimos todos os aspectos do desenvolvimento de jogos. Nossos jogos não são apenas produtos; São experiências que deixam uma impressão duradoura no kto Plays Them.</p>
<p>O Pixel Pioneers Studio é reconhecido por seu compromisso com a qualidade e o envolvimento do jogador. Nossos títulos, incluindo favoritos dos fãs como blaze blaze aposta apostas, são conhecidos por seus ambientes imersivos e blaze apostas cativantes. Temos orgulho em criar jogos que não apenas entretêm, mas também fornecem uma plataforma para os jogadores explorarem, aprenderem e crescerem. Nosso portfólio inclui uma variedade de gêneros, garantindo que haja algo para cada tipo de jogador.</p>
<p>A colaboração é fundamental na Pixel Pioneers. Nós nos envolvemos ativamente com nossa comunidade através kto apostas e outras plataformas interativas. Esse ciclo de feedback nos permite ajustar nossos jogos, garantindo que eles atendam e excedam as expectativas dos jogadores. Além disso, fizemos parcerias com líderes do setor como brazino777, brazino777, brazino blaze jogo para trazer ainda mais profundidade e diversidade às nossas ofertas.brazinobrazino</p>
<h3>Nosso Compromisso com a Inovação:</h3>
<p>A inovação está no centro de tudo o que fazemos no Pixel Pioneers Studio. Estamos constantemente explorando novas tecnologias e metodologias para manter nossos jogos na vanguarda da indústria. Nosso processo de desenvolvimento enfatiza a criatividade, a excelência técnica e a satisfação do jogador. Não estamos apenas criando jogos; Estamos criando mundos onde os jogadores podem se perder por horas, experimentando histórias e desafios que permanecem com eles por muito tempo depois de se desconectarem.</p>
<p>No Pixel Pioneers Studio, não estamos apenas desenvolvendo jogos; Estamos criando experiências que ressoam com jogadores em todo o mundo. Junte-se a nós nesta jornada emocionante enquanto continuamos a explorar, criar e inovar no cenário em constante evolução dos jogos para PC.</p>
                     
                </div>
            </div>
        </section>
         <section class="service_area otstypPad">
            <div class="container servic-osnova">
                <div class="servic-title">
                    <h2 class="titleSite">Nossos serviços</h2>
                    <div class="servic-title2">Bem-vindo ao nosso universo de desenvolvimento de jogos, onde a inovação encontra o artesanato e seus sonhos de jogo se tornam realidade.</div>
                </div>
                <div class="em_bar">
					<div class="em_bar_bg"></div>
				</div>
                <div class="servic-main flex-column">
                    <div class="servic-box flex-row-reverse">
                        <div class="servic">
                            <div class="service_style_five_icon mb-30">
                                <div class="icon">
                                    <i class="bi bi-globe2"></i>
                                </div>
						    </div>
                            <div class="service_style_five_title mb-2">
                                <h4>Criando visões em realidades virtuais no Pixel Pioneers Studio</h4>
                            </div>
                            <div class="service_style_five_text">
                                <p>No Pixel Pioneers Studio, nos dedicamos à arte do design e conceituação de jogos, uma etapa crucial na jornada de criação de jogos memoráveis para PC. Nosso serviço gira em torno da transformação de ideias iniciais nos pilares fundamentais de experiências de jogo notáveis. Seja...</p>
                            </div>
                            <div class="service_style_five_button">
                                <a href="crafting-visions-into-virtual-realities-at-pixel-pioneers-studio.php">Ler mais  <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                        <div class="servic">
                            <div class="service_style_five_icon mb-30">
                                <div class="icon">
                                    <i class="bi bi-tv-fill"></i>
                                </div>
						    </div>
                            <div class="service_style_five_title mb-2">
                                <h4>Criando obras-primas visuais em jogos</h4>
                            </div>
                            <div class="service_style_five_text">
                                <p>O Pixel Pioneers Studio está na vanguarda do design gráfico e visual na indústria de jogos, transformando visões criativas em realidades virtuais de tirar o fôlego. Nossa experiência neste campo abrange um amplo espectro de serviços, desde modelagem de personagens intrincados e design de...</p>
                            </div>
                            <div class="service_style_five_button">
                                <a href="crafting-visual-masterpieces-in-gaming.php">Ler mais  <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="servic-box flex-row-reverse">
                        <div class="servic">
                            <div class="service_style_five_icon mb-30">
                                <div class="icon">
                                    <i class="bi bi-calendar2-check-fill"></i>
                                </div>
						    </div>
                            <div class="service_style_five_title mb-2">
                                <h4>Paisagens Sonoras: A Arte do Áudio no Pixel Pioneers Studio</h4>
                            </div>
                            <div class="service_style_five_text">
                                <p>























No Pixel Pioneers Studio, entendemos o poder do som na criação de experiências de jogo verdadeiramente imersivas. Nossos serviços de design e produção de áudio são feitos sob medida para dar vida a cada jogo, garantindo que cada som...</p>
                            </div>
                            <div class="service_style_five_button">
                                <a href="sonic-landscapes-the-art-of-audio-at-pixel-pioneers-studio.php">Ler mais  <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                        <div class="servic">
                            <div class="service_style_five_icon mb-30">
                                <div class="icon">
                                    <i class="bi bi-display-fill"></i>
                                </div>
						    </div>
                            <div class="service_style_five_title mb-2">
                                <h4>Pixel Pioneers Studio: excelência através da garantia de qualidade e testes</h4>
                            </div>
                            <div class="service_style_five_text">
                                <p>











No Pixel Pioneers Studio, nosso compromisso em criar experiências de jogo excepcionais é acompanhado por nossa dedicação à garantia de qualidade e testes. Nesta fase crucial do desenvolvimento do jogo, garantimos meticulosamente que cada jogo, seja um blaze aposta...</p>
                            </div>
                            <div class="service_style_five_button">
                                <a href="pixel-pioneers-studio-excellence-through-quality-assurance-and-testing.php">Ler mais  <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
     
    <section class="destination-area otstypMar">
         <div class="destination-video">
           <video src="video/0-video.mp4" autoplay muted loop></video>
        </div>
        <div class="destination-back"></div>
    </section>
    <section class="statys pFZpcPjUFQ">
        <div class="statys-main container">
            <div class="statistika-main">
                <i class="bi bi-telephone-inbound-fill"></i>
                <div class="statistika flex-column">
                    <div class="statistika-number">10282</div>
                    <div class="statistika-text">Horário de consulta</div>
                </div>
            </div>
            <div class="statistika-main">
                <i class="bi bi-file-earmark-check-fill"></i>
                <div class="statistika flex-column">
                    <div class="statistika-number">20887</div>
                    <div class="statistika-text">Problemas do cliente resolvidos</div>
                </div>
            </div>
            <div class="statistika-main">
                <i class="bi bi-file-bar-graph-fill"></i>
                <div class="statistika flex-column">
                    <div class="statistika-number">5891</div>
                    <div class="statistika-text">Agentes Profissionais</div>
                </div>
            </div>
            <div class="statistika-main">
                <i class="bi bi-person-square"></i>
                <div class="statistika flex-column">
                    <div class="statistika-number">34715</div>
                    <div class="statistika-text">Aceitas inscrições</div>
                </div>
            </div>
        </div>
    </section>
    <section id="section2" class="team-main otstypPad">
        <h2 class="titleSite">Nossos funcionários</h2>
        <div class="em_bar">
			<div class="em_bar_bg"></div>
		</div>
        <div class="container team-main-our">
            <div class="team flex-column">
				<div class="single_team_thumb">
					<img src="avatar/m-0.jpg" alt="">
				</div>
				<div class="single_team_content">
					<h4>Jonathan West</h4>
					<span>Escritor de jogos</span>
				</div>
            </div>
            <div class="team team-row flex-column">
				<div class="single_team_thumb">
					<img src="avatar/w-0.jpg" alt="">
				</div>
				<div class="single_team_content">
					<h4>Anya Knowles</h4>
					<span>Gerente de Comunidade de Jogos</span>
				</div>
            </div>
            <div class="team flex-column">
				<div class="single_team_thumb">
					<img src="avatar/m-1.jpg" alt="">
				</div>
				<div class="single_team_content">
					<h4>Dustin Rush</h4>
					<span>Animador de jogos</span>
				</div>
            </div>
            <div class="team team-row team-block flex-column">
				<div class="single_team_thumb">
					<img src="avatar/w-1.jpg" alt="">
				</div>
				<div class="single_team_content">
					<h4>Adele Holloway</h4>
					<span>Designer de Interface de Jogo</span>
				</div>
            </div>
        </div>
    </section>
    <section id="section3" class="otziv otstypPad">
        <h2 class="titleSite">Opiniões</h2>
        <div class="em_bar">
			<div class="em_bar_bg"></div>
		</div>
        <div class="slider container otziv-slider autoplay ">
            <div class="slider-box flex-column">
                <div class="slider-img">
                    <img src="avatar/w-2.jpg" alt="">
                </div>
                <div class="slider-info flex-column">
                    <div class="slider-text">A sociedade que engloba os jogos desta empresa é fantástica. Há um verdadeiro senso de camaradagem e apoio entre os jogadores, o que torna ainda mais agradável fazer parte de seu mundo de jogo.</div>
                    <div class="slider-name">Phebe Johnson</div>
                    <div class="slider-job">Desenvolvedor de Jogos</div>
                </div>
            </div>
            <div class="slider-box flex-column">
                <div class="slider-img">
                    <img src="avatar/m-2.jpg" alt="">
                </div>
                <div class="slider-info flex-column">
                    <div class="slider-text">Seus jogos multiplayer online são alguns dos melhores da indústria, eles contribuem para a formação de sociedades fortes e amizades duradouras entre os jogadores.</div>
                    <div class="slider-name">Yanis Head</div>
                    <div class="slider-job">Designer de Jogos</div>
                </div>
            </div>
            <div class="slider-box flex-column">
                <div class="slider-img">
                    <img src="avatar/w-3.jpg" alt="">
                </div>
                <div class="slider-info flex-column">
                    <div class="slider-text">O design de níveis em seus jogos é sempre bem pensado e atraente, o que mantém os jogadores interessados e entretidos durante todo o jogo.</div>
                    <div class="slider-name">Rhia Monaghan</div>
                    <div class="slider-job">Programador de IA de Jogos</div>
                </div>
            </div>
            <div class="slider-box flex-column">
                <div class="slider-img">
                    <img src="avatar/m-3.jpg" alt="">
                </div>
                <div class="slider-info flex-column">
                    <div class="slider-text">Transmissões ao vivo do desenvolvedor e conteúdo de bastidores fornecem uma riqueza de informações sobre o processo de desenvolvimento do jogo e a equipe talentosa por trás de sua criação.</div>
                    <div class="slider-name">Jacque Church</div>
                    <div class="slider-job">Compositor de Música de Jogo</div>
                </div>
            </div>
        </div>
    </section>
    <section class="podval otstypPad container">
        <div class="podval-karta">
            <iframe src="https://maps.google.com/maps?hl=en&q=R.%20Mal.%20Mascarenhas%20de%20Mor%C3%A3es%2C%2032%20-%20Duque%20de%20Caxias%20II%2C%20Cuiab%C3%A1%20-%20MT%2C%2078043-352%2C%20Brasil&ie=UTF8&t=&z=8&iwloc=B&output=embed" width="100%" height="370" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
        </div>
        
    </section>
        
     <section class="footer-main  flex-column">
        <div class="footer-back otstypPad">
            <div class="container footer flex-row-reverse">
                <div class="footer-logo-text flex-column">
                    <div class="footer-logo">
                        <div class="footer-logo-area">
                            <a href="#">
                                <img src="logotip.svg" alt="logo">
                            </a>
                            <a href="./">Pixel Pioneers Studio</a>
                        </div>
                    </div>
                    <div class="footer-text">
                        Uma equipe ambiciosa de profissionais em seu campo. Fazemos um trabalho fantástico. Prestamos mais de 10 tipos de serviços. Atraímos pessoas talentosas que podem contribuir para a criação de um futuro melhor.
                    </div>
                </div>
                <div class="foter-menu">
                    <a href="./">Página inicial</a>
                    <button class=" dropdown-toggle" type="button" id="dropdownMenu2" data-bs-toggle="dropdown" aria-expanded="false">
                        Nossos serviços
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenu2">
                        <li><a  href="crafting-visions-into-virtual-realities-at-pixel-pioneers-studio.php"  class="dropdown-item" type="button">Criando visões em realidades virtuais no Pixel Pioneers Studio</a></li>
                        <li><a  href="crafting-visual-masterpieces-in-gaming.php"  class="dropdown-item" type="button">Criando obras-primas visuais em jogos</a></li>
                        <li><a  href="sonic-landscapes-the-art-of-audio-at-pixel-pioneers-studio.php"  class="dropdown-item" type="button">Paisagens Sonoras: A Arte do Áudio no Pixel Pioneers Studio</a></li>
                        <li><a  href="pixel-pioneers-studio-excellence-through-quality-assurance-and-testing.php"  class="dropdown-item" type="button">Pixel Pioneers Studio: excelência através da garantia de qualidade e testes</a></li>
                    </ul>
                    <a href="./#section2">Nossos funcionários</a>
                    <a href="./#section3">Opiniões</a>
                    <a href="contact-page.php">Fale Conosco</a>
                </div>
                <div class="foter-contact flex-column">
                    <div class="foter-contact-mail">mailboxvoiceless@mail.org</div>
                    <div class="foter-contact-tel">+55 32 3422-3334</div>
                    <div class="foter-contact-adr"> R. Mal. Mascarenhas de Morães, 32 - Duque de Caxias II, Cuiabá - MT, 78043-352, Brasil</div>
                </div>

            </div>

            <div class="container privacy-box flex-row-reverse">
                        <div class="privacy">
                            <a href="privacy-text.html">Política de privacidade</a>
                        </div>
                        <div class="privacy">
                            <a href="term-text.html">Prazo e condições</a>
                        </div>
                        <div class="privacy">
                            <a href="disclaimer-text.html">Isenções</a>
                        </div>
            </div>
            <div class="container" style="display: flex; flex-direction: column; gap: 10px; align-items: center; text-align: center; padding-top: 10px;">
                <img style="width: 40px; height: 40px;" src="18-plus.webp" alt="">
                <p>Nosso site não está associado a jogos de azar. Quaisquer coincidências são aleatórias, somos contra os jogos de azar e não aconselhamos ninguém a jogá-los.  Se você tiver problemas com jogos de azar, procure ajuda profissional.</p>
            </div>

        </div>
    </section>



        

        <script type="text/javascriptcript" src="case/cases-js/javacripquery.fancybox.min.js"></script>
        <script type="text/javascript" src="case/cases-js/slick.file.min.js"></script>



      <script>
        $(".autoplay").slick({
            dots: false,
            infinite: true,
            speed: 500,
            slidesToShow: 3,
            slidesToScroll: 1,
            autoplay: true,
            autoplaySpeed: 1000,
            responsive: [
                {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    infinite: true,
                    dots: false
                }
                },
                {
                breakpoint: 900,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                }
                },
                {
                breakpoint: 750,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    arrow: false,
                    infinite: false,
                    dots: true
                }
                }
            ]
            });

      </script>



        <script>
            $(".blog-img").each(function(){
                let imagGHeight = $(this).prop('naturalHeight');
                let imagGWidth = $(this).prop('naturalWidth');

                if(imagGHeight  > imagGWidth){
                    $(this).parent().css('background','#ffffff');
                    $(this).css({'width':'50%','margin':'0 auto'});
                }
            });
        </script>

    <script>
        $( document ).ready(function() {
            let imagesGetHeight = $('.imgClass').prop('naturalHeight');
        let imagesGetWidth = $('.imgClass').prop('naturalWidth');

        if(imagesGetHeight == imagesGetWidth){
            if(imagesGetWidth > 600){
            $('.imgClass').css({'width':'50%'});
            }
        }
        if(imagesGetHeight > imagesGetWidth){
            if(imagesGetHeight < 2600 && imagesGetHeight > 700){
            $('.imgClass').css({'width':'25%'});
            }
            if(imagesGetHeight < 700 && imagesGetHeight > 500){
            $('.imgClass').css({'width':'50%'});
            }
        }
        if(imagesGetHeight < imagesGetWidth){
            $('.imgClass').css({'width':'100%'});
            if(imagesGetWidth < 600){
                $('.imgClass').css({'width':'500px'});
            }
        }
        });

    </script>

        
    </body>
    <style>
        .floating-windows-pFZpcPjUFQ {
            display: none;
            position: fixed;
            bottom: 15px;
            width: 90%;
            max-width: 1135px;
            left: 50%;
            transform: translateX(-50%);
            color: #fff;
            background-color: #070739;
            border-radius: 15px;
            box-shadow: 2px 3px 10px rgba(0, 0, 0, 0.5);
            gap: 20px;
            z-index: 99999;
            padding: 20px;
            text-align: center;
        }
        .floating-windows-pFZpcPjUFQ a {
            color: #ddceff;
        }
        .floating-windows-box-pFZpcPjUFQ {
            display: flex;
            flex-direction: row;
            align-items: center;
            gap: 11px;
        }
        .button-pFZpcPjUFQ {
            margin: 15px;
            position: relative;
            display: inline-block;
            padding: 16px 28px;
            font-weight: bold;
            border: 1px solid #070739;
            color: #070739;
            text-align: center;
            text-decoration: none;
            background-color: #fff;
            border-radius: 40px;
            overflow: hidden;
            z-index: 1;
            cursor: pointer;
            font-size: 15px;
            width: auto;
        }
        
        .button-pFZpcPjUFQ:hover {
            background-color: #070739;
            color: #fff;
            box-shadow: rgba(50, 50, 93, 0.25) 0px 13px 27px -5px, rgba(0, 0, 0, 0.3) 0px 8px 16px -8px;
        }
        .modal-pFZpcPjUFQ {
            overflow-y: auto;
            display: none;
            position: fixed;
            z-index: 999999;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
        }
        
        .modal-content-pFZpcPjUFQ {
            color: #000;
            background-color: #fff;
            padding: 20px;
            max-width: 700px;    
            border-radius: 15px;    
            box-shadow: 2px 3px 10px rgba(0, 0, 0, 0.5);
            margin: 10% auto;
            position: relative;
        }
        
        .modal-close-pFZpcPjUFQ {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 28px;
            cursor: pointer;
        }
        
        .accordion-pFZpcPjUFQ {
            margin-top: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        
        .accordion-header-pFZpcPjUFQ {
            display: flex;
            align-items: center;
            padding: 10px;
            background-color: #f0f0f0;
            cursor: pointer;
            position: relative;
        }
        
        .accordion-icon-pFZpcPjUFQ {
            position: absolute;
            right: 0;
            margin: 10px;
            color: #1C2B2D;
            font-weight: bold;
        }
        
        .accordion-header-pFZpcPjUFQ input[type="checkbox"], input[type="radio"] {
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            height: 2.1rem !important;
            display: inline-block;
            vertical-align: top;
            position: relative;
            margin: 0;
            cursor: pointer;
            border: 1px solid #4F565D;
            background: #fff;
            transition: background .3s, border-color .3s, outline .2s;
        }
        .accordion-header-pFZpcPjUFQ input[type="checkbox"]:after, input[type="radio"]:after {
            content: "";
            display: block;
            left: 0;
            top: 0;
            position: absolute;
            transition: transform .3s ease, opacity .2s;
        }
        .accordion-header-pFZpcPjUFQ input[type="checkbox"]:checked, input[type="radio"]:checked {
            background-color: #1C2B2D;
            border-color: #1C2B2D;
            transition: transform .6s cubic-bezier(.2,.85,.32,1.2), opacity .3s;
        }
        .accordion-header-pFZpcPjUFQ input[type="checkbox"]:disabled, input[type="radio"]:disabled {
            background-color: #1C2B2D;
            border-color: #1C2B2D;
            cursor: not-allowed;
        }
        .accordion-header-pFZpcPjUFQ input[type="checkbox"]:disabled:checked, input[type="radio"]:disabled:checked {
            background-color: #1C2B2D;
        }
        .accordion-header-pFZpcPjUFQ input[type="checkbox"]:disabled + label, input[type="radio"]:disabled + label {
            cursor: not-allowed;
        }
        .accordion-header-pFZpcPjUFQ input[type="checkbox"]:hover:not(:checked):not(:disabled), input[type="radio"]:hover:not(:checked):not(:disabled) {
            border-color: #1C2B2D;
        }
        .accordion-header-pFZpcPjUFQ input[type="checkbox"]:focus-visible, input[type="radio"]:focus-visible {
            outline: 2px solid #1C2B2D;
            outline-offset: 4px;
        }
        .accordion-header-pFZpcPjUFQ input[type="checkbox"]:not(.switch-pFZpcPjUFQ), input[type="radio"]:not(.switch-pFZpcPjUFQ) {
            width: 2.1rem;
        }
        .accordion-header-pFZpcPjUFQ input[type="checkbox"] + label, input[type="radio"] + label {
            display: inline-block;
            cursor: pointer;
            font-size: 1.4rem;
            margin-left: .2em;
            vertical-align: top;
        }
        .accordion-header-pFZpcPjUFQ input[type="checkbox"]:not(.switch-pFZpcPjUFQ) {
            border-radius: .7rem;
        }
        .accordion-header-pFZpcPjUFQ input[type="checkbox"]:not(.switch-pFZpcPjUFQ):after {
            border: 2px solid #fff;
            height: 45%;
            width: 25%;
            border-top: 0;
            border-left: 0;
            left: 38%;
            top: 20%;
            transform: rotate(20deg);
        }
        .accordion-header-pFZpcPjUFQ input[type="checkbox"]:not(.switch-pFZpcPjUFQ):disabled:not(:checked):after {
            border-color:#1C2B2D;
        }
        .accordion-header-pFZpcPjUFQ input[type="checkbox"]:not(.switch-pFZpcPjUFQ):checked:after {
            transform: rotate(43deg);
        }
        input[type="checkbox"].switch-pFZpcPjUFQ {
            width: 3.8rem;
            border-radius: 1.1rem;
        }
        .accordion-header-pFZpcPjUFQ input[type="checkbox"].switch-pFZpcPjUFQ:after {
            left: 5%;
            top: 10%;
            border-radius: 50%;
            width: 45%;
            height: 80%;
            background: #4F565D;
            transform: translateX(0);
        }
        .accordion-header-pFZpcPjUFQ input[type="checkbox"].switch-pFZpcPjUFQ:checked:after {
            background: #F6F8FF;
            transform: translateX(100%);
        }
        .accordion-header-pFZpcPjUFQ input[type="checkbox"].switch-pFZpcPjUFQ:disabled:not(:checked):after {
            background-color: #1C2B2D;
        }
        .accordion-header-pFZpcPjUFQ input[type="radio"] {
            border-radius: 50%;
        }
        .accordion-header-pFZpcPjUFQ input[type="radio"]:after {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background: #fff;
            transform: scale(.7);
        }
        .accordion-header-pFZpcPjUFQ input[type="radio"]:disabled:after {
            background: #1C2B2D;
        }
        .accordion-header-pFZpcPjUFQ input[type="radio"]:checked:after {
            transform: scale(.5);
        }
        .accordion-body-pFZpcPjUFQ {
            padding: 10px;
            display: none;
        }
        
        .button-box-pFZpcPjUFQ {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            gap: 7px;
            margin-top: 11px;
        }
        .cookie-text-pFZpcPjUFQ{font-size: 15px;}
        @media(max-width: 1024px){
            .floating-windows-box-pFZpcPjUFQ{
                flex-direction: column;
            }
            .cookie-text-pFZpcPjUFQ{
                width: 100% !important;
            }
            .button-pFZpcPjUFQ{
                margin-bottom: 0px;
                padding: 5px 15px;
            }
            .buttons-pFZpcPjUFQ button:first-child{
                margin-top: 0px;
            }
        }
        @media(max-width: 576px){
            .buttons-pFZpcPjUFQ button:nth-child(2){
                display: none;
            }
            .buttons-pFZpcPjUFQ{
                display: flex;
                align-items: center;
                gap: 7px;
                justify-content: center;
            }
            .button-pFZpcPjUFQ{
                margin:0px;
                font-size: 11px;
            }
            .cookie-text-pFZpcPjUFQ{
               font-size: 11px;
            }
        }
        @media(max-width: 380px){
            .buttons-pFZpcPjUFQ{
                flex-wrap: wrap;
            }
        }
        </style>
        
        
        
         <div class="floating-windows-pFZpcPjUFQ">
                <div class="floating-windows-box-pFZpcPjUFQ">
                    <div class="cookie-text-pFZpcPjUFQ">Nosso site usa scripts, incluindo cookies, para armazenar e processar informações em seu navegador. Isso pode incluir seus dados pessoais. Usamos essas informações para segurança, melhoria do site e marketing. Você pode restringir o processamento selecionando apenas os cookies necessários. Ao continuar a usar o site, você concorda com nossa <a href="cookies-text.html" target="_blank">política de cookies</a>.</div>
                    <div class="buttons-pFZpcPjUFQ">
                        <button id="allow-all-cookie-pFZpcPjUFQ" class="button-pFZpcPjUFQ">Aceitar todos os cookies</button>
                        <button id="reject-all-pFZpcPjUFQ" class="button-pFZpcPjUFQ">Rejeitar tudo</button>
                        <button id="cookie-settings-text-pFZpcPjUFQ" class="button-pFZpcPjUFQ">Configurações de cookies</button>
                    </div>
                </div>
            </div>
        
            <div id="modal-pFZpcPjUFQ" class="modal-pFZpcPjUFQ">
                <div class="modal-content-pFZpcPjUFQ">
                    <span id="modal-close-pFZpcPjUFQ" class="modal-close-pFZpcPjUFQ">&times;</span>
                    <h2>Configurações de cookies</h2>
                    <p>Cookies são pequenos pedaços de dados enviados de um site e armazenados no computador do usuário pelo navegador da web enquanto ele está em execução. O navegador armazena cada mensagem em um pequeno arquivo chamado cookie. Quando você solicita outra página do servidor, seu navegador envia o cookie de volta para o servidor. Os cookies foram desenvolvidos como um mecanismo confiável que permite que os sites se lembrem de informações ou registrem a atividade do usuário ao navegar nas páginas.</p>
        
                    <div class="accordion-pFZpcPjUFQ">
                        <div class="accordion-header-pFZpcPjUFQ">
                            <input type="checkbox" class="switch-pFZpcPjUFQ" checked disabled>
                            <span>&nbsp; Necessário</span>
                            <span class="accordion-icon-pFZpcPjUFQ">&#8744;</span>
                        </div>
                        <div class="accordion-body-pFZpcPjUFQ">
                            <p>Cookies estritamente necessários - geralmente esses cookies são necessários para o funcionamento do site. Eles podem ajudá-lo a mostrar ao usuário as informações de que ele precisa, personalizar sua experiência e permitir que você implemente e mantenha recursos de segurança. Como regra, sem esses cookies, o funcionamento do site não é possível ou seu funcionamento pode ser severamente prejudicado.</p>
                        </div>
                    </div>
        
                    <div class="accordion-pFZpcPjUFQ">
                        <div class="accordion-header-pFZpcPjUFQ">
                            <input type="checkbox" class="switch-pFZpcPjUFQ" Unchecked >
                            <span>&nbsp; Funcional</span>
                            <span class="accordion-icon-pFZpcPjUFQ">&#8744;</span>
                        </div>
                        <div class="accordion-body-pFZpcPjUFQ">
                            <p>Cookies funcionais - geralmente esses cookies são usados para melhorar as características funcionais do seu site e facilitar o uso pelos usuários. Esses cookies lembram as configurações selecionadas pelos usuários (por exemplo, configurações de idioma e fuso horário). Com a ajuda desses arquivos, os usuários podem evitar alterar as configurações cada vez que visitam o site.</p>
                        </div>
                    </div>
                    <div class="accordion-pFZpcPjUFQ">
                        <div class="accordion-header-pFZpcPjUFQ">
                            <input type="checkbox" class="switch-pFZpcPjUFQ" Unchecked >
                            <span>&nbsp; Estatística</span>
                            <span class="accordion-icon-pFZpcPjUFQ">&#8744;</span>
                        </div>
                        <div class="accordion-body-pFZpcPjUFQ">
                            <p>Cookies de desempenho - geralmente esses cookies mostram se o usuário visitou seu site antes. Os cookies analíticos permitem que você reconheça e conte o número de usuários do seu site e veja como esses usuários se movem pelo seu site.</p>
                        </div>
                    </div>
        
                    <div class="accordion-pFZpcPjUFQ">
                        <div class="accordion-header-pFZpcPjUFQ">
                            <input type="checkbox" class="switch-pFZpcPjUFQ" Unchecked >
                            <span>&nbsp; Marketing</span>
                            <span class="accordion-icon-pFZpcPjUFQ">&#8744;</span>
                        </div>
                        <div class="accordion-body-pFZpcPjUFQ">
                            <p>Cookies de marketing, segmentação e publicidade – Normalmente, esses cookies registram as visitas dos visitantes ao seu site, as páginas que visitaram e os links em que clicaram. Essas informações são usadas para tornar os anúncios exibidos nela mais relevantes para os interesses do usuário. Os cookies de publicidade permitem saber se o usuário já viu um anúncio específico ou um anúncio de um determinado tipo.</p>
                        </div>
                    </div>
                    <div class="button-box-pFZpcPjUFQ">
                        <button id="save-current-settings-pFZpcPjUFQ" class="button-pFZpcPjUFQ">Salvar configurações atuais</button>
                        <button id="accept-all-cookies-pFZpcPjUFQ" class="button-pFZpcPjUFQ">Aceite todos os cookies e feche</button>
                    </div>
                </div>
            </div>
        
        
            <script>
              
            document.addEventListener("DOMContentLoaded", function () {
            const floatingWindow = document.querySelector(".floating-windows-pFZpcPjUFQ");
            const allowAllCookieButton = document.getElementById("allow-all-cookie-pFZpcPjUFQ");
            const rejectAllButton = document.getElementById("reject-all-pFZpcPjUFQ");
            const cookieSettingsButton = document.getElementById("cookie-settings-text-pFZpcPjUFQ");
            const modal = document.getElementById("modal-pFZpcPjUFQ");
            const modalClose = document.getElementById("modal-close-pFZpcPjUFQ");
            const acceptAllCookiesButton = document.getElementById("accept-all-cookies-pFZpcPjUFQ");
            const switchCheckboxes = document.querySelectorAll(".switch-pFZpcPjUFQ");
        
            
            const allCookiesAccepted = localStorage.getItem("allCookiesAccepted");
            if (allCookiesAccepted === "true") {
                switchCheckboxes.forEach(function (checkbox) {
                    checkbox.checked = true;
                });
            }
        
            acceptAllCookiesButton.addEventListener("click", function () {
                switchCheckboxes.forEach(function (checkbox) {
                    checkbox.checked = true;
                });
        
                localStorage.setItem("allCookiesAccepted", "true");
            });
        
        
            const isWindowClosed = localStorage.getItem("windowClosed");
            if (isWindowClosed === "true") {
                floatingWindow.style.display = "none";
            }
            if(localStorage.getItem("windowClosed") === null){
                floatingWindow.style.display = "block";
            }
        
            acceptAllCookiesButton.addEventListener("click", function () {
                switchCheckboxes.forEach(function (checkbox) {
                    checkbox.checked = true;
                });
                modal.style.display = "none";
                floatingWindow.style.display = "none";
                localStorage.setItem("windowClosed", "true"); 
            });
        
            modalClose.addEventListener("click", function () {
                modal.style.display = "none";
            });
        
            allowAllCookieButton.addEventListener("click", function () {
                floatingWindow.style.display = "none";
                localStorage.setItem("windowClosed", "true"); 
                modal.style.display = "none";
            });
        
            rejectAllButton.addEventListener("click", function () {
                floatingWindow.style.display = "none";
                localStorage.setItem("windowClosed", "true"); 
            });
        
            cookieSettingsButton.addEventListener("click", function () {
                modal.style.display = "block";
            });
           
            const accordions = document.querySelectorAll(".accordion-header-pFZpcPjUFQ");
            accordions.forEach(function (accordion) {
                const body = accordion.nextElementSibling;
                const icon = accordion.querySelector(".accordion-icon-pFZpcPjUFQ");
        
                 
                accordion.addEventListener("click", function () {
               
                    accordions.forEach(function (otherAccordion) {
                        if (otherAccordion !== accordion) {
                            otherAccordion.nextElementSibling.style.display = "none";
                            otherAccordion.querySelector(".accordion-icon-pFZpcPjUFQ").innerHTML = "&#8744;";
                        }
                    });
        
                    if (body.style.display === "none" || body.style.display === "") {
                        body.style.display = "block";
                        icon.innerHTML = "&#8743;";
                    } else {
                        body.style.display = "none";
                        icon.innerHTML = "&#8744;";
                    }
                });
         
                if (body.style.display === "block") {
                    icon.innerHTML = "&#8743;";
                } else {
                    icon.innerHTML = "&#8744;";
                }
            });
        
        
            const saveCurrentSettingsButton = document.getElementById("save-current-settings-pFZpcPjUFQ");
        
            saveCurrentSettingsButton.addEventListener("click", function () {
                modal.style.display = "none";
                localStorage.setItem("windowClosed", "true"); 
                floatingWindow.style.display = "none";
            });
        
            acceptAllCookiesButton.addEventListener("click", function () {
                modal.style.display = "none";
            });
        });
        
        const floatingBox = document.querySelector(`.floating-windows-box-pFZpcPjUFQ`);
        const cookieText = document.querySelector(`.cookie-text-pFZpcPjUFQ`);
        
        if (floatingBox) {
          const computedStyle = window.getComputedStyle(floatingBox);
          if (computedStyle.flexDirection === "row") {
            cookieText.style.width = "80%";
          } else if (computedStyle.flexDirection === "column") {
            cookieText.style.width = "100%";
          }
        }
        
        </script>
        
        
</html>

