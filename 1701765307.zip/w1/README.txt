Что бы создать sitemap.xml:
    1. Залейте на хостинг весь вайт.
    2. Откройте в браузере файл installSitemap.php, пример: https://domain.com/installSitemap.php
    3. После этого код сделает новый файл sitemap.xml в корне домена
    4. Код перезапишет файл robots.txt
    5. Если вы сменили домен, вам нужно будет повторить эту процедуру


To create a sitemap.xml:
    1. Pour the entire White Page on the hosting.
    2. Open the installSitemap.php file in your browser, for example: https://domain.com/installSitemap.php
    3. After this code will make a new sitemap.xml file in the root of the domain
    4. The code will overwrite the robots.txt file
    5. If you have changed the domain, you will need to repeat this procedure
